import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PantryPopoverPage } from './pantry-popover';

@NgModule({
  declarations: [
    PantryPopoverPage,
  ],
  imports: [
    IonicPageModule.forChild(PantryPopoverPage),
  ],
})
export class PantryPopoverPageModule {}
