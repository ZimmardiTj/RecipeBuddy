import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { ModelService } from '../../../core/services/model.service';
import { ObjectService } from '../../../core/services/object.service';
import { HelperService } from '../../../core/services/helper.service';

/**
 * Generated class for the PantryPopoverPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-pantry-popover',
  templateUrl: 'pantry-popover.html',
})
export class PantryPopoverPage implements OnInit {

  modelName = 'items';
  model: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private viewCtrl: ViewController
  ) {
  }

  ngOnInit() {
  }

  close() {
    this.viewCtrl.dismiss('closed');
  }

  new() {
    this.viewCtrl.dismiss('new');
  }

  search() {
    this.viewCtrl.dismiss('search');
  }

}
