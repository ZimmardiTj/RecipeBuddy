import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, PopoverController, ModalController } from 'ionic-angular';
import { ObjectService } from '../../core/services/object.service';
import { ModelService } from '../../core/services/model.service';
import { LoadingWrapperService } from '../../core/wrappers/loading-wrapper.service';
import { PantryPopoverPage } from './pantry-popover/pantry-popover';
import { HelperService } from '../../core/services/helper.service';
import { Storage } from '@ionic/storage';
import { NewFormPage } from '../new-form/new-form';
import { SearchPage } from '../search/search';

/**
 * Generated class for the PantryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-pantry',
  templateUrl: 'pantry.html',
})
export class PantryPage implements OnInit {

  modelName = 'items';
  items: any[] = [];
  displayField: string;
  model: any;
  recipeType = 'private';
  user: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private objectService: ObjectService,
    private modelService: ModelService,
    private popoverCtrl: PopoverController,
    private helper: HelperService,
    private modalCtrl: ModalController,
    private storage: Storage
  ) {
  }

  ngOnInit() {
    this.storage.get('currentUser').then(user => {
      this.user = user;
    });
  }

  doRefresh(refresher) {
    this.objectService.getObjects(this.modelName).subscribe(res => {
      if (res.results.length > 0) {
        this.items = res.results;
      }
      refresher.complete();
    });
  }

  select(item) {
    const i = this.user.pantry.indexOf(item);
    const updateItem = this.user.pantry[i];

    this.modelService.getModel('items').subscribe(model => {
      let mobileView;
      model.views.forEach(v => {
        if (v.name === 'mobile') {
          mobileView = v;
        }
      });
      let modal = this.modalCtrl.create(NewFormPage, {
        form: updateItem,
        fields: model.fields,
        views: mobileView.fields,
        model: 'items',
        edit: true
      });
      modal.present();
      modal.onDidDismiss(data => {
        if (data) {
          if (data._id) {

            this.user.pantry.forEach((p, idx) => {
              if (p.name == data.name) {
                this.user.pantry[idx] = data;
              };
            });

            this.helper.updateUser(this.user).then();
          }
        }
      });
    });
  }

  more(event) {
    const popover = this.popoverCtrl.create(PantryPopoverPage);
    popover.present({ ev: event });
    popover.onDidDismiss(res => {
      if (res == 'new') {
        this.add();
      } else if(res == 'search') {
        this.search();
      }
    });
  }

  search() {
    this.objectService.getObjects('items').subscribe(res => {
      let modal = this.modalCtrl.create(SearchPage, { items: res.results, field: 'name' });
      modal.present();
      modal.onDidDismiss(data => {
        if (data) {
          if (data._id) {

            this.user.pantry.push(data);
  
            this.helper.updateUser(this.user).then();
          }
        }
      });
    });
  }

  add() {
    this.modelService.getModel('items').subscribe(res => {
      this.model = res;
      this.helper.create(this.model, this.modelName).then(res => {
        this.user.pantry.push(res);

        this.helper.getUser().then(user => {

          user.pantry.push(res);

          this.helper.updateUser(user).then(response => {
          });
        });
      });
    });
  }

  delete(item) {

    const idx = this.user.pantry.indexOf(item);
    this.user.pantry.splice(idx, 1);

    this.helper.updateUser(this.user).then();

  }

  addToGrocery(item) {
    this.user.groceryList.push(item);

    this.helper.updateUser(this.user).then();
  }

}
