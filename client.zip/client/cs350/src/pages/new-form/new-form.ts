import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, LoadingController, Events } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ObjectService } from '../../core/services/object.service';

@IonicPage()
@Component({
  selector: 'page-new-form',
  templateUrl: 'new-form.html',
})
export class NewFormPage {

  fields: any;
  views: any;
  form: any = {};
  model: any;
  title: string;
  loading: boolean;
  done: any;

  signature: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private viewCtrl: ViewController,
    private loadingCtrl: LoadingController,
    private objectService: ObjectService,
    private events: Events,
    private storage: Storage
  ) {
  }

  ionViewDidLoad() {
    this.fields = this.navParams.data.fields;
    this.views = this.navParams.data.views;

    this.model = this.navParams.data.model;
    this.title = this.navParams.data.title;
    this.form = this.navParams.data.form;

    if (this.navParams.data.edit) {
      this.done = 'Update';
    } else {
      this.done = 'Add'
    }
  }

  onValuesChange(event) {
    this.form = event;
    let localForm = {
      model: {
        title: this.title,
        name: this.model
      },
      form: this.form,
      date: new Date().toDateString()
    }
    // this.storage.set(this.model, localForm);
    this.events.publish(this.model, localForm);
  }

  finish() {
    const loading = this.loadingCtrl.create({
      content: 'Submiting data...',
      enableBackdropDismiss: true,
      duration: 5000
    });
    loading.present();
    if (this.navParams.data.edit) {
      this.objectService.updateObject(this.model, this.form._id, this.form).subscribe(res => {
        loading.dismiss();
        this.viewCtrl.dismiss(this.form);
        this.events.publish('object:updated', true);
      });
    } else {
      this.objectService.createObject(this.model, this.form).subscribe(res => {
        this.storage.remove(this.model);
        loading.dismiss();
        this.viewCtrl.dismiss(res);
        this.events.publish('object:updated', true);
      });
    }
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

}
