import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController, ModalController } from 'ionic-angular';
import { HelperService } from '../../core/services/helper.service';
import { ModelService } from '../../core/services/model.service';
import { PantryPopoverPage } from '../pantry/pantry-popover/pantry-popover';
import { ObjectService } from '../../core/services/object.service';
import { SearchPage } from '../search/search';
import { GroceryListPopoverPage } from './grocery-list-popover/grocery-list-popover';

/**
 * Generated class for the GroceryListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-grocery-list',
  templateUrl: 'grocery-list.html',
})
export class GroceryListPage implements OnInit {

  user: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private helper: HelperService,
    private popoverCtrl: PopoverController,
    private objectService: ObjectService,
    private modalCtrl: ModalController,
    private modelService: ModelService
    ) {
  }

  ngOnInit() {
    this.helper.getUser().then(user => {
      this.user = user;
    });
  }

  add() {
    this.modelService.getModel('items').subscribe(res => {
      const model = res;
      this.helper.create(model, 'items').then(res => {
        this.user.groceryList.push(res);

        this.helper.getUser().then(user => {

          user.groceryList.push(res);

          this.helper.updateUser(user).then(response => {
          });
        });
      });
    });
  }

  search() {
    this.objectService.getObjects('items').subscribe(res => {
      let modal = this.modalCtrl.create(SearchPage, { items: res.results, field: 'name' });
      modal.present();
      modal.onDidDismiss(data => {
        if (data) {
          if (data._id) {

            this.user.groceryList.push(data);
  
            this.helper.updateUser(this.user).then();
          }
        }
      });
    });
  }

  more(event) {
    const popover = this.popoverCtrl.create(GroceryListPopoverPage);
    popover.present({ ev: event });
    popover.onDidDismiss(res => {
      if (res == 'new') {
        this.add();
      } else if(res == 'search') {
        this.search();
      }
    });
  }

  delete(item) {

    const idx = this.user.groceryList.indexOf(item);
    this.user.groceryList.splice(idx, 1);

    this.helper.updateUser(this.user).then();

  }

}
