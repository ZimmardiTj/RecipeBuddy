import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the GroceryListPopoverPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-grocery-list-popover',
  templateUrl: 'grocery-list-popover.html',
})
export class GroceryListPopoverPage {

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private viewCtrl: ViewController
    ) {
  }

  close() {
    this.viewCtrl.dismiss('closed');
  }

  search() {
    this.viewCtrl.dismiss('search');
  }

}
