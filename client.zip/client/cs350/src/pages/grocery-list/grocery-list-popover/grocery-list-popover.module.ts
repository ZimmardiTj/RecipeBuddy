import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GroceryListPopoverPage } from './grocery-list-popover';

@NgModule({
  declarations: [
    GroceryListPopoverPage,
  ],
  imports: [
    IonicPageModule.forChild(GroceryListPopoverPage),
  ],
})
export class GroceryListPopoverPageModule {}
