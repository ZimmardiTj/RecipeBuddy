import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { LoadingController, AlertController } from 'ionic-angular';
import { Storage } from '@ionic/storage';

import { AppService } from '../../app/app.service';
import { HomePage } from '../home/home';
import { ObjectService } from '../../core/services/object.service';
import { LoginService } from '../../core/services/login.service';
import { TokenService } from '../../core/services/token.service';
import { PantryPage } from '../pantry/pantry';
import { SettingsPage } from '../settings/settings';
import { RecipesPage } from '../recipes/recipes';
import { GroceryListPage } from '../grocery-list/grocery-list';
import { ProfilePage } from '../profile/profile';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage implements OnInit {

  user: any = {};
  failedLogin: boolean = false;
  loading: any;
  logo: string;
  company: string;
  rootPage: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private loadingCtrl: LoadingController,
    private alertController: AlertController,
    private storage: Storage,
    private loginService: LoginService,
    private appService: AppService,
    private tokenService: TokenService,
    private objectService: ObjectService
  ) {

    this.storage.get('settingsStore').then(settings => {
      if(settings) {
        let homePage = settings['Home Page'];
        if(homePage == 'Pantry') {
          this.rootPage = PantryPage;
        } else if(homePage == 'Settings') {
          this.rootPage = SettingsPage;
        } else if(homePage == 'Recipes') {
          this.rootPage = RecipesPage;
        } else if(homePage == 'Grocery List') {
          this.rootPage = GroceryListPage;
        } else if(homePage == 'Profile') {
          this.rootPage = ProfilePage;
        } else {
          this.rootPage = HomePage;
        }
      } else {
        this.rootPage = HomePage;
      }
    });
  }

  ngOnInit() {
    this.company = 'Chicken Tacos';
    this.storage.set('company', this.company);
    // this.appService.nlogoRetrieve().subscribe(res => {
    //   // this.logo = res[1].value;
    //   this.company = res[0].value;

    //   // this.storage.set('logo', this.logo);
    //   this.storage.set('company', this.company);
    // });
  }

  ionViewDidLoad() {
    this.loading = this.loadingCtrl.create({
      content: 'Reviewing login information...'
    });
    this.loading.present();
    this.storage.get('access_token').then(token => {
      if (token != null) {
        this.tokenService.setToken(token);
        // this.loginService.testAuth().subscribe(auth => {
        // TODO remove this
        // auth = 'validated';
        if (token) {
          this.storage.get('currentUser').then(user => {
            console.log(user);
            this.objectService.getObject('users', user._id, {
              populate: ['pantry', 'favorites', 'groceryList']
            }).subscribe(res => {
              this.loading.dismiss();
              this.navCtrl.setRoot(this.rootPage);
            }, err => {
              this.loading.dismiss();
            });
          }, err => {
            this.loading.dismiss();
          });
        } else {
          this.failedLogin = true;
          this.loading.dismiss();
        }
        // }, err => {
        //   this.loading.dismiss();
        // });
      } else {
        this.loading.dismiss();
      }
    }, err => {
      this.loading.dismiss();
    });
  }

  login() {
    this.loading = this.loadingCtrl.create({
      content: 'Logging you in...',
      enableBackdropDismiss: true,
      duration: 5000
    });
    this.loading.present();
    this.loginService.login(this.user.email, this.user.password).subscribe(res => {
      // Not sure why I need to do the next few lines.... but if I don't everything breaks...
      this.objectService.getObjects('users', {
        email: this.user.email
      }).subscribe(user => {
        if (res) {
          this.navCtrl.setRoot(this.rootPage);
          this.loading.dismiss();
        }
      });
    }, err => {
      let alert = this.alertController.create({
        title: 'Error',
        message: 'Unable to log you in',
        buttons: ['Ok']
      });
      alert.present();
      this.loading.dismiss();
    });
  }

}
