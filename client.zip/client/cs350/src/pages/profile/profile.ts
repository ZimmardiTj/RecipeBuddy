import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ObjectService } from '../../core/services/object.service';
import { ToastWrapperService } from '../../core/wrappers/toast-wrapper.service';
/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage implements OnInit {
  user: any = {
     friends: []
  };
  newFriend: string;

  constructor(
    private objectSerice: ObjectService,
    public navCtrl: NavController,
    public navParams: NavParams,
    private storage: Storage,
    private toastrCtrl: ToastWrapperService
  ) {
    this.storage.get('currentUser').then(user => {
      this.user = user;
    });

  }

  ngOnInit() {

  }

  addFriend() {
    this.objectSerice.getObjects('users', { email: this.newFriend }).subscribe(res => {
      if (res.results.length != 0) {
        const toast = this.toastrCtrl.success('Succesfully sent friend request');
        toast.present();
      } else {
        const toast = this.toastrCtrl.error('User does not exist');
        toast.present();
      }
    });
  }
}
