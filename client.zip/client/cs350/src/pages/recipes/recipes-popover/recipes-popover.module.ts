import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RecipesPopoverPage } from './recipes-popover';

@NgModule({
  declarations: [
    RecipesPopoverPage,
  ],
  imports: [
    IonicPageModule.forChild(RecipesPopoverPage),
  ],
})
export class RecipesPopoverPageModule {}
