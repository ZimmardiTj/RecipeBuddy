import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, PopoverController, ModalController } from 'ionic-angular';
import { ObjectService } from '../../core/services/object.service';
import { ModelService } from '../../core/services/model.service';
import { LoadingWrapperService } from '../../core/wrappers/loading-wrapper.service';
import { RecipesPopoverPage } from './recipes-popover/recipes-popover';
import { SingleRecipePage } from './single-recipe/single-recipe';
import { Storage } from '@ionic/storage';
import { HelperService } from '../../core/services/helper.service';
import { ToastWrapperService } from '../../core/wrappers/toast-wrapper.service';

/**
 * Generated class for the RecipesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-recipes',
  templateUrl: 'recipes.html',
})
export class RecipesPage implements OnInit {

  modelName = 'recipes';
  items: any[] = [];
  displayField: string;
  model: any;
  recipeType = 'private';
  user: any;
  filterParameters = {};
  searchTerm: string;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private objectService: ObjectService,
    private modelService: ModelService,
    private loadingCtrl: LoadingWrapperService,
    private alertCtrl: AlertController,
    private popoverCtrl: PopoverController,
    private modalCtrl: ModalController,
    private storage: Storage,
    private helper: HelperService,
    private toastrCtrl: ToastWrapperService
  ) {
    this.storage.get('currentUser').then(user => {
      this.user = user;
    });
  }

  ngOnInit() {
    this.modelService.getModel(this.modelName).subscribe(model => {
      this.model = model;
      this.displayField = model.displayField;
      this.objectService.getObjects(this.modelName, {
        populate: ['owner', 'items'],
        owner: this.user._id
      }).subscribe(res => {
        this.items = res.results;
      });
    });
  }

  /* Apply Filters */
  onInput(searchTerm: string) {
    this.filterParameters['$or'] = [];

    if(this.searchTerm != '') {
      this.model.fields.forEach(field => {
        var newProp = {};
  
        if (field.type == 'String') {
          newProp[field.name] = { '$regex': this.searchTerm, '$options': 'i' };
          this.filterParameters['$or'].push(newProp);
        }
      });
  
      this.objectService.getObjects(this.modelName, {
        populate: ['owner', 'items'],
        ...this.filterParameters
      }).subscribe(res => {
        this.items = res.results;
      });
    } else {
      this.objectService.getObjects(this.modelName, {
        populate: ['owner', 'items']
      }).subscribe(res => {
        this.items = res.results;
      });
    }
  }

  doRefresh(refresher) {
    if (this.recipeType == 'private') {
      this.objectService.getObjects(this.modelName, {
        populate: ['owner', 'items'],
        owner: this.user._id,
        ...this.filterParameters
      }).subscribe(res => {
        if (res.results.length > 0) {
          this.items = res.results;
        }
        refresher.complete();
      });
    } else if(this.recipeType == 'public') {
      this.objectService.getObjects(this.modelName, {
        populate: ['owner', 'items'],
        ...this.filterParameters
      }).subscribe(res => {
        if (res.results.length > 0) {
          this.items = res.results;
        }
        refresher.complete();
      });
    } else {
      refresher.complete();
    }
  }

  more(event) {
    const popover = this.popoverCtrl.create(RecipesPopoverPage);
    popover.present({ ev: event });
    popover.onDidDismiss(res => {
      if (res == 'new') {
        this.add();
      }
    });
  }

  select(item) {
    const modal = this.modalCtrl.create(SingleRecipePage, { recipe: item, model: this.model });
    modal.present();
    modal.onDidDismiss(data => {
    });
  }

  add() {
    this.helper.create(this.model, this.modelName).then(res => {
      if(res == 'new') {
        const toast = this.toastrCtrl.success('Succesfully added recipe');
        toast.present();
      }
    });
  }

  changeType(event) {
    this.recipeType = event.value;
    if (event.value == 'private') {
      this.objectService.getObjects(this.modelName, {
        populate: ['owner', 'items'],
        owner: this.user._id
      }).subscribe(res => {
        this.items = res.results;
      });
    } else if (event.value == 'public') {
      this.objectService.getObjects(this.modelName, {
        populate: ['owner', 'items']
      }).subscribe(res => {
        this.items = res.results;
      });
    } else if (event.value == 'favorites') {
      this.helper.getUser().then(user => {
        this.items = user.favorites;
      });
    }
  }

}
