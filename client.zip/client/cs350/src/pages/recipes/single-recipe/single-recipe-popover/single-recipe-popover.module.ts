import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SingleRecipePopoverPage } from './single-recipe-popover';

@NgModule({
  declarations: [
    SingleRecipePopoverPage,
  ],
  imports: [
    IonicPageModule.forChild(SingleRecipePopoverPage),
  ],
})
export class SingleRecipePopoverPageModule {}
