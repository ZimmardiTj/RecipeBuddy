import { Component, Input, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, PopoverController, LoadingController, ModalController } from 'ionic-angular';
import { SingleRecipePopoverPage } from './single-recipe-popover/single-recipe-popover';
import { NewFormPage } from '../../new-form/new-form';
import { LoadingWrapperService } from '../../../core/wrappers/loading-wrapper.service';
import { ObjectService } from '../../../core/services/object.service';
import { HelperService } from '../../../core/services/helper.service';
import { Storage } from '@ionic/storage';
import { ToastWrapperService } from '../../../core/wrappers/toast-wrapper.service';


/**
 * Generated class for the SingleRecipePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-single-recipe',
  templateUrl: 'single-recipe.html',
})
export class SingleRecipePage implements OnInit {

  recipe: any;
  model: any;
  user: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private popoverCtrl: PopoverController,
    private viewCtrl: ViewController,
    private loadingCtrl: LoadingWrapperService,
    private modalCtrl: ModalController,
    private objectService: ObjectService,
    private storage: Storage,
    private helper: HelperService,
    private toastrCtrl: ToastWrapperService
  ) {
    this.helper.getUser().then(user => {
      this.user = user;
    });
  }

  ngOnInit() {
    this.recipe = this.navParams.data.recipe;
    this.model = this.navParams.data.model;
  }

  close() {
    this.viewCtrl.dismiss();
  }

  more(event) {
    const popover = this.popoverCtrl.create(SingleRecipePopoverPage);
    popover.present({ev: event});
    popover.onDidDismiss(res => {
      if(res == 'edit') {
        this.edit();
      } else if(res == 'share') {
        this.share();
      } else if(res == 'created') {
        this.createdBy();
      } else if(res == 'favorite') {
        this.favorite();
      } else if(res == 'cook') {
        this.cook();
      }
    });
  }

  edit() {
    this.helper.edit(this.recipe, false, this.model, this.user).then(res => {
      this.recipe = res;
    });
  }

  share() {
    this.helper.share(this.recipe).then(res => {
    });
  }

  favorite() {
   this.user.favorites.push(this.recipe);
   this.helper.updateUser(this.user).then();
   const toast = this.toastrCtrl.success('Added recipe to favorites');
   toast.present();
  }

  createdBy() {
    
  }

  cook() {
    this.helper.cook(this.recipe, this.user).then(res => {
    });
  }

}
