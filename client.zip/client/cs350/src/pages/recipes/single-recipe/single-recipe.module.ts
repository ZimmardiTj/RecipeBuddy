import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SingleRecipePage } from './single-recipe';

@NgModule({
  declarations: [
    SingleRecipePage,
  ],
  imports: [
    IonicPageModule.forChild(SingleRecipePage),
  ],
})
export class SingleRecipePageModule {}
