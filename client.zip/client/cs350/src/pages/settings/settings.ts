import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';

/**
 * Generated class for the SettingsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class SettingsPage implements OnInit {

  settings: any[];
  settingsStore: any = {};

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private storage: Storage
  ) {
    this.settings = [
      {
        title: 'Home Page',
        icon: 'home',
        type: 'discrete',
        description: 'What page do you want to show up automatically when you sign in?',
        options: [
          {
            title: 'Explore'
          },
          {
            title: 'Recipes'
          },
          {
            title: 'Pantry'
          },
          {
            title: 'Grocery List'
          },
          {
            title: 'Profile'
          },
          {
            title: 'Settings'
          }
        ]
      }
    ]
  }

  ngOnInit() {
    this.storage.get('settingsStore').then(settings => {
      if(settings) {
        this.settingsStore = settings;
      }
    });
  }

  update() {
    this.storage.set('settingsStore', this.settingsStore);
  }

}
