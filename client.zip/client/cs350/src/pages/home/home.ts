import { Component, OnInit } from '@angular/core';
import { NavController, ModalController, AlertController, PopoverController } from 'ionic-angular';
import { ObjectService } from '../../core/services/object.service';
import { ModelService } from '../../core/services/model.service';
import { LoadingWrapperService } from '../../core/wrappers/loading-wrapper.service';
import { HomePopoverPage } from './home-popover/home-popover';
import { SearchPage } from '../search/search';
import { ToastWrapperService } from '../../core/wrappers/toast-wrapper.service';
import { Storage } from '@ionic/storage';
import { HelperService } from '../../core/services/helper.service';
import { SingleRecipePage } from '../recipes/single-recipe/single-recipe';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit {

  modelName = 'recipes';
  items: any[] = [];
  displayField: string;
  model: any;
  user: any;
  filterParameters = {};
  searchTerm: string;

  constructor(
    public navCtrl: NavController,
    private objectService: ObjectService,
    private modelService: ModelService,
    private loadingCtrl: LoadingWrapperService,
    private popoverCtrl: PopoverController,
    private toastCtrl: ToastWrapperService,
    private modalCtrl: ModalController,
    private storage: Storage,
    private helper: HelperService
  ) {
    this.storage.get('currentUser').then(user => {
      this.user = user;
    });
  }

  ngOnInit() {
    this.modelService.getModel(this.modelName).subscribe(model => {
      this.model = model;
      this.displayField = model.displayField;
      this.objectService.getObjects(this.modelName, {
        skip: 0,
        limit: 3,
        populate: ['owner', 'items']
      }).subscribe(res => {
        this.items = res.results;
      });
    });
  }

  /* Apply Filters */
  onInput(searchTerm: string) {
    this.filterParameters['$or'] = [];

    if(this.searchTerm != '') {
      this.model.fields.forEach(field => {
        var newProp = {};
  
        if (field.type == 'String') {
          newProp[field.name] = { '$regex': this.searchTerm, '$options': 'i' };
          this.filterParameters['$or'].push(newProp);
        }
      });
  
      this.objectService.getObjects(this.modelName, {
        ...this.filterParameters
      }).subscribe(res => {
        this.items = res.results;
      });
    } else {
      this.objectService.getObjects(this.modelName, {
        skip: 0,
        limit: 3
      }).subscribe(res => {
        this.items = res.results;
      });
    }
  }

  select(item) {
    const modal = this.modalCtrl.create(SingleRecipePage, { recipe: item, model: this.model });
    modal.present();
    modal.onDidDismiss(data => {
    });
  }

  doRefresh(refresher) {
    this.objectService.getObjects(this.modelName, {
      skip: 0,
      limit: 3
    }).subscribe(res => {
      if (res.results.length > 0) {
        this.items = res.results;
      }
      refresher.complete();
    });
  }

  more(event) {
    const popover = this.popoverCtrl.create(HomePopoverPage);
    popover.present({ ev: event });
    popover.onDidDismiss(res => {
      if (res == 'new') {
        this.add();
      }
    });
  }

  add() {
    this.helper.create(this.model, this.modelName).then(res => {
      this.items.push(res);
    });
  }

  favorite(item) {
    const toast = this.toastCtrl.success('Added recipe to favorites');
    toast.present();
  }

  share(item) {
    this.helper.share(item).then(res => {
    });
  }

  edit(item, isCopied) {
    this.helper.edit(item, isCopied, this.model, this.user).then(res => {
      if (res) {
        const toast = this.toastCtrl.success('Succesfully edited recipe');
        toast.present();
      }
    });
  }

  userOwns(item) {
    if(item.owner) {
      if (item.owner._id == this.user._id) {
        return true;
      }
    }

    return false;
  }

  onCancel(event) {
  }

}
