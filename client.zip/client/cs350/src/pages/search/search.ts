import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
})
export class SearchPage {

  items: any = [];
  field: string = 'name';

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private viewCtrl: ViewController
  ) {
  }

  ionViewDidLoad() {
    this.initializeItems();
  }

  removeDups() {
    let unique = [];
    let m = {};
    this.items.forEach(item => {
      if(!m[item[this.field]]) {
        unique.push(item);
        m[item[this.field]] = true;
      }
    });
    this.items = unique;
  }

  initializeItems() {
    this.items = this.navParams.data.items;
    this.field = this.navParams.data.field;
    this.removeDups();
  }

  getItems(event) {
    this.initializeItems();

    let val = event.target.value;
    if (val && val.trim() != '') {
      this.items = this.items.filter((item) => {
        return (item[this.field].toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }

  selectItem(item) {
    this.viewCtrl.dismiss(item);
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

}
