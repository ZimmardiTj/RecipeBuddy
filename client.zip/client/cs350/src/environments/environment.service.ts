import { Injectable } from '@angular/core';
import { ENV } from './environment';

@Injectable()
export class EnvironmentService {

  constructor() {
  }

  getApiUrl() {
    if (ENV.currentEnvironment === "production") {
      return ENV.production.apiUrl;
    }
  }

  getNeutrinoApiUrl() {
    return ENV.production.neutrinoAPI;
  }
}
