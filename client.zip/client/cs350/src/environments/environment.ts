export class ENV {

  public static currentEnvironment: string = "production";

  public static production: any = {
      apiUrl: "https://platform.maphey.com/api/v1",
      neutrinoAPI: "https://platform.maphey.com/api/v1/sys"
  };
}
