import { NgModule } from '@angular/core';
import { TimerPipe } from './timer/timer';
@NgModule({
	declarations: [TimerPipe],
	imports: [],
	exports: [TimerPipe]
})
export class PipesModule {}
