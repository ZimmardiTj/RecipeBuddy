import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { HttpClientModule } from '@angular/common/http';
import { IonicStorageModule } from '@ionic/storage';
import { MyApp } from './app.component';
import { Camera } from '@ionic-native/camera';

import { HomePage } from '../pages/home/home';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { EnvironmentService } from '../environments/environment.service';
import { AppService } from './app.service';
import { ObjectService } from '../core/services/object.service';
import { ModelService } from '../core/services/model.service';
import { TokenService } from '../core/services/token.service';
import { LoginService } from '../core/services/login.service';

import { ToastWrapperService } from '../core/wrappers/toast-wrapper.service';
import { LoadingWrapperService } from '../core/wrappers/loading-wrapper.service';


import { SearchPage } from '../pages/search/search';
import { NewFormPage } from '../pages/new-form/new-form';
import { NreferencePage } from '../core/components/nfield/nreference/nreference';
import { NstringPage } from '../core/components/nfield/nstring/nstring';
import { NdatePage } from '../core/components/nfield/ndate/ndate';
import { NfieldPage } from '../core/components/nfield/nfield';
import { NbooleanPage } from '../core/components/nfield/nboolean/nboolean';
import { NobjectPage } from '../core/components/nfield/nobject/nobject';
import { NnumberPage } from '../core/components/nfield/nnumber/nnumber';
import { NarrayPage } from '../core/components/nfield/narray/narray';
import { HomePopoverPage } from '../pages/home/home-popover/home-popover';
import { RecipesPage } from '../pages/recipes/recipes';
import { RecipesPopoverPage } from '../pages/recipes/recipes-popover/recipes-popover';
import { PantryPage } from '../pages/pantry/pantry';
import { PantryPopoverPage } from '../pages/pantry/pantry-popover/pantry-popover';
import { ProfilePage } from '../pages/profile/profile';
import { SettingsPage } from '../pages/settings/settings';
import { LoginPage } from '../pages/login/login';
import { SingleRecipePage } from '../pages/recipes/single-recipe/single-recipe';
import { SingleRecipePopoverPage } from '../pages/recipes/single-recipe/single-recipe-popover/single-recipe-popover';
import { HelperService } from '../core/services/helper.service';
import { TimerPage } from '../core/components/timer/timer';
import { TimerPipe } from '../pipes/timer/timer';
import { GroceryListPage } from '../pages/grocery-list/grocery-list';
import { GroceryListPopoverPage } from '../pages/grocery-list/grocery-list-popover/grocery-list-popover';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    HomePopoverPage,
    RecipesPage,
    RecipesPopoverPage,
    SingleRecipePage,
    SingleRecipePopoverPage,
    PantryPage,
    GroceryListPage,
    GroceryListPopoverPage,
    PantryPopoverPage,
    ProfilePage,
    SettingsPage,
    TimerPipe,
    LoginPage,
    TimerPage,
    SearchPage,
    NewFormPage,
    NreferencePage,
    NstringPage,
    NdatePage,
    NfieldPage,
    NbooleanPage,
    NobjectPage,
    NnumberPage,
    NarrayPage
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicStorageModule.forRoot(),
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    HomePopoverPage,
    RecipesPage,
    RecipesPopoverPage,
    SingleRecipePage,
    SingleRecipePopoverPage,
    PantryPage,
    PantryPopoverPage,
    GroceryListPage,
    GroceryListPopoverPage,
    ProfilePage,
    SettingsPage,
    LoginPage,
    TimerPage,
    SearchPage,
    NewFormPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    EnvironmentService,
    AppService,
    ToastWrapperService,
    LoadingWrapperService,
    ObjectService,
    ModelService,
    TokenService,
    LoginService,
    HelperService,
    Camera,
  ]
})
export class AppModule {}
