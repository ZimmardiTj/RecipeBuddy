import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { EnvironmentService } from '../environments/environment.service';

@Injectable()
export class AppService {

  constructor(
    private http: HttpClient,
    private environment: EnvironmentService
  ) { }

  get(url): Observable<any> {
    return this.http.get(this.environment.getApiUrl() + '/' + url);
  }

  put(url, obj): Observable<any> {
    return this.http.put(this.environment.getApiUrl() + '/' + url, obj);
  }

  post(url, obj): Observable<any> {
    return this.http.post(this.environment.getApiUrl() + '/' + url, obj);
  }

  delete(url): Observable<any> {
    return this.http.delete(this.environment.getApiUrl() + '/' + url);
  }

  nget(url): Observable<any> {
    return this.http.get(this.environment.getNeutrinoApiUrl() + '/' + url);
  }

  nput(url, obj): Observable<any> {
    return this.http.put(this.environment.getNeutrinoApiUrl() + '/' + url, obj);
  }

  npost(url, obj): Observable<any> {
    return this.http.post(this.environment.getNeutrinoApiUrl() + '/' + url, obj);
  }

  ndelete(url): Observable<any> {
    return this.http.delete(this.environment.getNeutrinoApiUrl() + '/' + url);
  }

  // nlogoRetrieve(): Observable<any> {
  //   return this.http.get(this.environment.getNeutrinoApiUrl() + '/settings');
  // }

}
