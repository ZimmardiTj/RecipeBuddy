import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the NobjectPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nobject',
  templateUrl: 'nobject.html',
})
export class NobjectPage implements OnInit {

  @Input() field: any;
  @Input() view: any;
  @Input() obj: any;

  form: any = {};

  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ngOnInit() {
    if(this.obj) {
      this.form = this.obj;
    }
  }

  onValueChange(event, field) {
    this.form[field.name] = event;
    this.valueChange.emit(this.form);
  }

  valueForField(field) {
    let v;
    if(this.form) {
      Object.keys(this.form).forEach(key => {
        if(key == field.name) {
          v = this.form[key];
        }
      });
    }
    return v;
  }; 

}
