import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NobjectPage } from './nobject';

@NgModule({
  declarations: [
    NobjectPage,
  ],
  imports: [
    IonicPageModule.forChild(NobjectPage),
  ],
})
export class NobjectPageModule {}
