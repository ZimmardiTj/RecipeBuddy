import { Component, Input, Output, EventEmitter } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the NdatePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-ndate',
  templateUrl: 'ndate.html',
})
export class NdatePage {

  @Input() field: any;
  @Input() class: string;
  @Input() view: any;
  @Input() value: any;

  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
  }

  onChange() {
    this.valueChange.emit(this.value);
  }

}
