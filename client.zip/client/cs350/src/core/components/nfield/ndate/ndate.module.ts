import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NdatePage } from './ndate';

@NgModule({
  declarations: [
    NdatePage,
  ],
  imports: [
    IonicPageModule.forChild(NdatePage),
  ],
})
export class NdatePageModule {}
