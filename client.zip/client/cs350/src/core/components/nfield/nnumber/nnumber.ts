import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the NnumberPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nnumber',
  templateUrl: 'nnumber.html',
})
export class NnumberPage implements OnInit {

  @Input() field: any;
  @Input() class: string;
  @Input() view: any;
  @Input() value: any;

  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ngOnInit() {
  }

  ionViewDidLoad() {
  }

  onChange() {
    this.valueChange.emit(this.value);
  }

}
