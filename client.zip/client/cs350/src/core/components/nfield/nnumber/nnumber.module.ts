import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NnumberPage } from './nnumber';

@NgModule({
  declarations: [
    NnumberPage,
  ],
  imports: [
    IonicPageModule.forChild(NnumberPage),
  ],
})
export class NnumberPageModule {}
