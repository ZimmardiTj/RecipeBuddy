import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NbooleanPage } from './nboolean';

@NgModule({
  declarations: [
    NbooleanPage,
  ],
  imports: [
    IonicPageModule.forChild(NbooleanPage),
  ],
})
export class NbooleanPageModule {}
