import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NarrayPage } from './narray';

@NgModule({
  declarations: [
    NarrayPage,
  ],
  imports: [
    IonicPageModule.forChild(NarrayPage),
  ],
})
export class NarrayPageModule {}
