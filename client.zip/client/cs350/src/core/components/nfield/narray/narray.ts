import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the NarrayPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-narray',
  templateUrl: 'narray.html',
})
export class NarrayPage implements OnInit {

  @Input() field: any;
  @Input() view: any;
  @Input() obj: any;

  items: any = [];
  filledItems: any = [];

  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ngOnInit() {
    if(!this.obj) {
      this.items = [this.field];
      this.filledItems[0] = {};
    } else {
      this.obj.forEach(o => {
        this.filledItems.push(o);
        this.items.push(this.field);
      });
    }
  }

  onValueChange(event, field, idx) {
    this.filledItems[idx][field.name] = event;
    this.valueChange.emit({item: this.filledItems[idx], index: idx});
  }

  addItem() {
    this.items.push(this.field);
    this.filledItems.push({});
  }

  removeItem(idx) {
    this.items.splice(idx, 1);
    this.filledItems.splice(idx, 1);
    this.valueChange.emit({item: this.filledItems[idx], index: idx});
  }

  valueForField(field, i) {
    let v;
    if(this.obj) {
      if (this.obj[i]) {
        this.obj.forEach((o, idx) => {
          if(o) {
            Object.keys(o).forEach(key => {
              if (key == field.name && i == idx) {
                v = this.obj[idx][key];
              }
            });
          }
        });
      }
    }
    return v;
  };

}
