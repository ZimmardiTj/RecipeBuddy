import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NfieldPage } from './nfield';

@NgModule({
  declarations: [
    NfieldPage,
  ],
  imports: [
    IonicPageModule.forChild(NfieldPage),
  ],
})
export class NfieldPageModule {}
