import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the NfieldPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nfield',
  templateUrl: 'nfield.html',
})
export class NfieldPage implements OnInit {

  @Input() fields: any;
  @Input() views: any;
  @Input() form: any;

  @Output() valuesChange: EventEmitter<any> = new EventEmitter<any>();

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ngOnInit() {
  }

  ionViewDidLoad() {
  }

  onValueChange(event, field) {

    if (field.type == 'Array') {
      if (!this.form[field.name]) {
        this.form[field.name] = [];
      }
      if(event.item) {
        if(field.arrayType != 'Object') {
          this.form[field.name][event.index] = event.item[field.name];
        } else {
          this.form[field.name][event.index] = event.item;
        }
      } else {
        this.form[field.name].splice(event.index, 1);
      }
    } else {
      this.form[field.name] = event;
    }
    this.valuesChange.emit(this.form);
  }

  viewForField(field) {
    let view;
    this.views.forEach(v => {
      if (v.field == field._id) {
        view = v;
      }
    });
    return view;
  }

  valueForField(field) {
    let v;
    if (this.form) {
      Object.keys(this.form).forEach(key => {
        if (key == field.name) {
          v = this.form[key];
        }
      });
    }
    return v;
  };

}
