import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, LoadingController } from 'ionic-angular';
import { SearchPage } from '../../../../pages/search/search';
import { ObjectService } from '../../../services/object.service';

/**
 * Generated class for the NreferencePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nreference',
  templateUrl: 'nreference.html',
})
export class NreferencePage implements OnInit {

  @Input() field: any;
  @Input() class: string;
  @Input() view: any;
  @Input() obj;
  @Input() fromArray: boolean;

  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();

  selected: any = 'search';
  display: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private modalCtrl: ModalController,
    private loadingCtrl: LoadingController,
    private objectService: ObjectService) {
  }

  ngOnInit() {
    if(this.field.referenceModel == 'users') {
      this.display = 'email';
      // filters = {'assignments.role': this.field.displayName}
    } else {
      this.display = 'name';
    }

    if(this.obj) {
      this.selected = this.obj[this.display];
    }
  }

  search() {
    const loading = this.loadingCtrl.create({
      content: 'Retreiving data...'
    });
    loading.present();
    let filters;
    this.objectService.getObjects(this.field.referenceModel).subscribe(res => {
      let modal = this.modalCtrl.create(SearchPage, { items: res.results, field: this.display });
      modal.present();
      loading.dismiss();
      modal.onDidDismiss(data => {
        if(data) {
          this.selected = data[this.display];
          this.valueChange.emit(data._id);
        }
      });
    });
  }

}
