import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NreferencePage } from './nreference';

@NgModule({
  declarations: [
    NreferencePage,
  ],
  imports: [
    IonicPageModule.forChild(NreferencePage),
  ],
})
export class NreferencePageModule {}
