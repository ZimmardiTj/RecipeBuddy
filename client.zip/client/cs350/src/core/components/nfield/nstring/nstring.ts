import { Component, Output, EventEmitter, Input, OnInit, ViewChild, ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';

import { Camera, CameraOptions } from '@ionic-native/camera';
import { Storage } from '@ionic/storage';

/**
 * Generated class for the NstringPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nstring',
  templateUrl: 'nstring.html',
})
export class NstringPage implements OnInit {

  @ViewChild('file') fileInput: ElementRef;

  @Input() field: any;
  @Input() class: string;
  @Input() view: any;
  @Input() value: any;
  @Input() fromArray: boolean;

  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();

  platform: string;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private modalCtrl: ModalController,
    private camera: Camera,
    private storage: Storage
  ) {
    this.storage.get('platform').then(plat => {
      this.platform = plat;
    });
  }

  ngOnInit() {
    this.storage.get('platform').then(plat => {
      this.platform = plat;
    });
  }

  checkForChoices() {
    if(this.field.choices) {
      if(this.field.choices.length > 0) {
        return true;
      }
    }
    return false;
  }

  onChange() {
    this.valueChange.emit(this.value);
  }

  selectImg() {
    const options: CameraOptions = {
      quality: 25,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    }

    this.camera.getPicture(options).then((imageData) => {
      // imageData is either a base64 encoded string or a file URI
      // If it's base64 (DATA_URL):
      this.value = 'data:image/jpeg;base64,' + imageData;
      this.valueChange.emit(this.value);
     }, (err) => {
      // Handle error
     });
  }

  triggerFileInputClick() {
    this.fileInput.nativeElement.click();
  }
  
  onFileInputChange(files: FileList) {
    const reader = new FileReader();

    reader.addEventListener('load', () => {
      this.value = reader.result;
      this.valueChange.emit(this.value);
    });

    reader.readAsDataURL(files[0]);
  }
}
