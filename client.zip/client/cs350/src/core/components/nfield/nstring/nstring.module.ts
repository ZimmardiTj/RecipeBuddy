import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NstringPage } from './nstring';

@NgModule({
  declarations: [
    NstringPage,
  ],
  imports: [
    IonicPageModule.forChild(NstringPage),
  ],
})
export class NstringPageModule {}
