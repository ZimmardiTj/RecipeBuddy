import { Component } from '@angular/core';
import { IonicPage } from 'ionic-angular';
import { Observable } from 'rxjs';
import { ActionSheetController } from 'ionic-angular'
import { ToastWrapperService } from '../../wrappers/toast-wrapper.service';

/**
 * Generated class for the TimerPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-timer',
  templateUrl: 'timer.html',
})
export class TimerPage {

  mins = 30;
  countDown: Observable<any>;
  counter = this.mins * 60;
  tick = 1000;
  paused: boolean;

  constructor(
    private actionSheetCtrl: ActionSheetController,
    private toastrCtrl: ToastWrapperService
  ) {
  }

  ionViewDidLoad() {
  }

  changeTime() {
    let actionSheet = this.actionSheetCtrl.create({
      title: 'Timer',
      buttons: [
        {
          text: '30 mins',
          role: '30',
          handler: () => {
            this.mins = 30;
          }
        },
        {
          text: '15 mins',
          handler: () => {
            this.mins = 15;
          }
        },
        {
          text: '5 mins',
          role: '5',
          handler: () => {
            this.mins = 5;
          }
        },
        {
          text: '2 mins',
          role: '2',
          handler: () => {
            this.mins = 2;
          }
        },
        {
          text: 'Cancel',
          role: 'cancel'
        }
      ]
    });

    actionSheet.present();
    actionSheet.onDidDismiss(data => {
      this.counter = this.mins * 60;
    });
  }

  start() {
    this.paused = false;
    this.countDown = Observable.timer(0, this.tick)
      .take(this.counter)
      .map(() => {
        if (this.counter / 60 == 1) {
          const toast = this.toastrCtrl.warning('1 minute remaining');
          toast.present();
        }

        if(this.counter == 1) {
          const toast = this.toastrCtrl.error('timer done');
          toast.present();
        }

        if (!this.paused) {
          return --this.counter;
        } else {
          return this.counter;
        }
      })
  }

  stop() {
    this.paused = true;
  }

}
