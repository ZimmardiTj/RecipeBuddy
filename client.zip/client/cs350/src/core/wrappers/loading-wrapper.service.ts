import { Injectable } from '@angular/core';
import { LoadingController } from 'ionic-angular';

@Injectable()
export class LoadingWrapperService {

  constructor(
    private loadingCtrl: LoadingController
  ) { }

  create(content: string) {
    const loading = this.loadingCtrl.create({
      content: content,
      enableBackdropDismiss: true,
      duration: 3000,
    });

    return loading;
  }
}
