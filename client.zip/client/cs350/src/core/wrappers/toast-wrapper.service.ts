import { Injectable } from '@angular/core';
import { ToastController } from 'ionic-angular';

@Injectable()
export class ToastWrapperService {

  constructor(
    private toastCtrl: ToastController
  ) { }

  success(message: string) {
    const toast = this.toastCtrl.create({
      message: message,
      duration: 3000,
      position: 'bottom',
      showCloseButton: true,
      closeButtonText: 'OK',
      cssClass: 'toast-success'
    });

    return toast;
  }

  error(message: string) {
    const toast = this.toastCtrl.create({
      message: message,
      duration: 3000,
      position: 'bottom',
      showCloseButton: true,
      closeButtonText: 'OK',
      cssClass: 'toast-error'
    });

    return toast;
  }

  info(message: string) {
    const toast = this.toastCtrl.create({
      message: message,
      duration: 3000,
      position: 'bottom',
      showCloseButton: true,
      closeButtonText: 'OK',
      cssClass: 'toast-info'
    });

    return toast;
  }

  warning(message: string) {
    const toast = this.toastCtrl.create({
      message: message,
      duration: 3000,
      position: 'bottom',
      showCloseButton: true,
      closeButtonText: 'OK',
      cssClass: 'toast-warning'
    });

    return toast;
  }
}
