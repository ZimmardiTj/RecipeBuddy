import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import { ObjectService } from './object.service';
import { EnvironmentService } from '../../environments/environment.service';
import { AppService } from '../../app/app.service';
import { TokenService } from './token.service';

@Injectable()
export class LoginService {

  constructor(
    private http: HttpClient,
    private storage: Storage,
    private environment: EnvironmentService,
    private _service: AppService,
    private tokenService: TokenService,
    private objectservice: ObjectService
  ) {

  }

  login(email: string, password: string): Observable<any> {
    return this.http.post(this.environment.getApiUrl() + '/authenticate', { email: email, password: password }).map((res: any) => {
      var token = res.token;
      var user = res.data;

      if (user && token) {
        this.objectservice.getObject('users', user._id, {
          populate: ['pantry', 'favorites', 'groceryList']
        }).subscribe(userData => {
          this.storage.set('currentUser', userData.results);
          if(userData.results.roles) {
            if(userData.results.roles.length > 0) {
              userData.results.roles.forEach(role => {
                if(role.name == 'admin') {
                  this.storage.set('isAdmin', true);
                }
              });
            } else {
              this.storage.set('isAdmin', false);
            }
          } else {
            this.storage.set('isAdmin', false);
          }
          this.storage.set('access_token', token);
          this.tokenService.setToken(token);
        });
        return token;
      } else {
        return null;
      }
    });
  }

  logout() {
    this.storage.remove('currentUser');
    this.storage.remove('access_token');
  }

  testAuth() {
    return this._service.get('authenticate');
  }

}
