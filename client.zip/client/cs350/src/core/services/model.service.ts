import { Injectable } from '@angular/core';

import { AppService } from '../../app/app.service';

@Injectable()
export class ModelService {

  constructor(
    private _service: AppService,
  ) { }

  getModels(params = null) {
    let url = 'models/';

    if (params) {
      if (params.populate) {
        params.populate = '[' + params.populate.join() + ']';
      }

      url += this.serializeURI(params);
    }

    return this._service.nget(url);
  }

  getModel(id: any, params = null) {
    let url = 'models/' + id;

    if (params) {
      if (params.populate) {
        params.populate = '[' + params.populate.join() + ']';
      }

      url += this.serializeURI(params);
    }

    return this._service.nget(url);
  }

  viewForField(field, views) {
    let view;
    views.forEach(v => {
      if (v.field == field._id) {
        view = v;
      }
    });
    return view;
  }

  getViewForModel(id: any, view: any) {
    return this._service.nget('models/' + id + '/views/' + view);
  }

  getRelatedModels(model) {
    return this._service.nget('models/' + model + '/related');
  }

  createModel(model) {
    return this._service.npost('models', model);
  }

  updateModel(id, model) {
    return this._service.nput('models/' + id, model);
  }

  deleteModels(models) {
    return this._service.ndelete('models?ids=[' + models.join() + ']');
  }

  createField(modelId, field) {
    return this._service.npost('models/' + modelId + '/fields', field);
  }

  updateField(modelId, fieldId, field) {
    return this._service.nput('models/' + modelId + '/fields/' + fieldId, field);
  }

  deleteFields(modelId, fields) {
    return this._service.ndelete('models/' + modelId + '/fields?ids=[' + fields.join() + ']');
  }

  createView(modelId, view) {
    return this._service.npost('models/' + modelId + '/views', view);
  }

  updateView(modelId, viewId, view) {
    return this._service.nput('models/' + modelId + '/views/' + viewId, view);
  }

  deleteViews(modelId, views) {
    return this._service.ndelete('models/' + modelId + '/views?ids=[' + views.join() + ']');
  }

  serializeURI(obj) {
    return '?' + Object.keys(obj).reduce(function(a, k){a.push(k + '=' + encodeURIComponent(obj[k])); return a; }, []).join('&');
  }
}
