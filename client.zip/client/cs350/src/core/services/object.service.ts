import { Injectable } from '@angular/core';
import { AppService } from '../../app/app.service';

@Injectable()
export class ObjectService {

  constructor(
    private _service: AppService,
  ) { }

  getObjects(collectionName, params = null) {
    let url = collectionName;

    if (params) {
      if (params.populate) {
        params.populate = '[' + params.populate.join() + ']';
      }

      Object.keys(params).forEach(key => {
        if(typeof params[key] === 'object' || Array.isArray(params[key])) {
          params[key] = JSON.stringify(params[key]);
        }
      });

      url += this.serializeURI(params);
    }
    return this._service.get(url);
  }

  getObject(collectionName, objectId, params = null) {
    let url = collectionName + '/' + objectId;

    if (params) {
      if (params.populate) {
        params.populate = '[' + params.populate.join() + ']';
      }

      Object.keys(params).forEach(key => {
        if(typeof params[key] === 'object') {
          params[key] = JSON.stringify(params[key]);
        }
      });

      url += this.serializeURI(params);
    }

    return this._service.get(url);
  }

  createObject(collectionName, object) {
    return this._service.post(collectionName, object);
  }

  updateObject(collectionName, objectId, object) {
    return this._service.put(collectionName + '/' + objectId, object);
  }

  updateObjects(collectionName, ids, update) {
    return this._service.put(collectionName + '?ids=[' + ids.join() + ']', update);
  }

  deleteObjects(collectionName, ids) {
    return this._service.delete(collectionName + '?ids=[' + ids.join() + ']');
  }

  serializeURI(obj) {
    return '?' + Object.keys(obj).reduce(function(a, k){a.push(k + '=' + encodeURIComponent(obj[k])); return a; }, []).join('&');
  }
}
