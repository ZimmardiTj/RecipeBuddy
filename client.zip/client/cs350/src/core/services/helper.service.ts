import { Injectable } from '@angular/core';
import { LoadingWrapperService } from '../wrappers/loading-wrapper.service';
import { AlertController, ModalController } from 'ionic-angular';
import { NewFormPage } from '../../pages/new-form/new-form';
import { resolveDefinition } from '@angular/core/src/view/util';
import { ObjectService } from './object.service';
import { SearchPage } from '../../pages/search/search';
import { ToastWrapperService } from '../wrappers/toast-wrapper.service';
import { RecipesPage } from '../../pages/recipes/recipes';
import { Storage } from '@ionic/storage';

@Injectable()
export class HelperService {

  constructor(
    private loadingCtrl: LoadingWrapperService,
    private alertCtrl: AlertController,
    private modalCtrl: ModalController,
    private toastCtrl: ToastWrapperService,
    private objectService: ObjectService,
    private storage: Storage
  ) {
  }

  create(model: any, modelName): Promise<any> {
    return new Promise((resolve, reject) => {
      const loading = this.loadingCtrl.create('Gathering data...');
      loading.present();
      let mobileView;
      model.views.forEach(v => {
        if (v.name === 'mobile') {
          mobileView = v;
        }
      });
  
      if (!mobileView) {
        let alert = this.alertCtrl.create({
          title: 'Need to create a mobile form',
          message: 'In order to add a form you must create a mobile view in the web app',
          buttons: [
            {
              text: 'OK',
              role: null
            }
          ]
        });
        alert.present();
        loading.dismiss();
      } else {
        let modal = this.modalCtrl.create(NewFormPage, {
          fields: model.fields,
          views: mobileView.fields,
          form: {},
          model: modelName,
          title: 'Add Recipe',
          edit: false
        });
        modal.present();
        loading.dismiss();
        modal.onDidDismiss(data => {
          if (data) {
            resolve(data)
          }
        });
      }
    });
  }

  edit(item: any, isCopied: boolean, model: any, user: any): Promise<any> {
    return new Promise(resolve => {
      let edit = !isCopied;
      const loading = this.loadingCtrl.create('Gathering data');
      loading.present();
  
      let mobileView;
      model.views.forEach(v => {
        if (v.name === 'mobile') {
          mobileView = v;
        }
      });
  
      this.objectService.getObject('recipes', item._id, {
        populate: ['owner']
      }).subscribe(res => {
        if(!edit) {
          delete res.results._id;
          res.results.owner = user;
        }
        let modal = this.modalCtrl.create(NewFormPage, {
          form: res.results,
          fields: model.fields,
          views: mobileView.fields,
          model: 'recipes',
          edit: edit
        });
        modal.present();
        loading.dismiss();
        modal.onDidDismiss(data => {
          if (data) {
            if (data._id) {
              resolve(data);
            }
          }
        });
      });
    });

  }

  share(item: any): Promise<any> {
    return new Promise(resolve => {
      const loading = this.loadingCtrl.create('Gathering data');
      loading.present();
      this.objectService.getObjects('users').subscribe(res => {
        let modal = this.modalCtrl.create(SearchPage, {
          items: res.results,
          field: 'email'
        });
        modal.present();
        loading.dismiss();
        modal.onDidDismiss(data => {
          // TODO: This does not actually do anything, no notification has been sent to the user that the recipe was shared with
          const toast = this.toastCtrl.success('Succesfully shared recipe with ' + data.email);
          toast.present();
          resolve(data);
        });
      });
    });
  }

  cook(recipe: any, user: any): Promise<any> {
    return new Promise(resolve => {
      const nonExistent = []
      recipe.items.forEach(item => {
        const i = user.pantry.find(p => p.name == item.name);

        if(i) {
          i.quantity--;
          if(i.quantity <= i.limit) {
            const toast = this.toastCtrl.warning('You have hit your limit in you pantry for ' + i.name + '.');
            toast.present();
          };

          user.pantry.forEach((p, idx) => {
            if(p.name == i.name) {
              user.pantry[idx] = i;
            };
          });

          this.updateUser(user).then(u => {
          });
          
        } else {
          nonExistent.push(item);
        }
      });

      resolve(nonExistent);
    });
  }

  getUser(): Promise<any> {
    return new Promise(resolve => {
      this.storage.get('currentUser').then(user => {
        resolve(user);
      });
    });
  }

  updateUser(newUser: any): Promise<any> {
    return new Promise(resolve => {
      this.storage.get('currentUser').then(user => {

        this.objectService.updateObject('users', user._id, newUser).subscribe(res => {
          this.storage.set('currentUser', newUser);
        });
      });
    });
  }

}
