import { Injectable } from '@angular/core';

@Injectable()
export class TokenService {

  token: string;

  constructor(
  ) {

  }

  getToken() {
    return this.token;
  }

  setToken(token: string) {
    this.token = token;
  }

}
