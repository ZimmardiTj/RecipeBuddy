import os
import sys

def deploy(username):
  os.system("cd cs350 && scp -r www/ " + username + "@maphey.com:/var/www/html/recipes.maphey.com/")

if __name__ == "__main__":
  deploy(sys.argv[1])
